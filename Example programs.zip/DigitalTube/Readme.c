21/6/1:
	需要更改
	1.// 显示数字
		initial begin
        data[31:28] = 2;
        data[27:24] = 0;
        data[23:20] = 2;
        data[19:16] = 1;
        data[15:12] = 0;
        data[11:8]  = 6;
        data[7:4]   = 0;
        data[3:0]   = 8;
    end
