21/6/1:
	需要更改
	1.// 定义数组
		reg[7:0]store[19:0]; 
	2.// 存储发送字符
		initial begin
			...
			store[18] = 13   ; // 换行
			store[19] = 10   ; // CR
		end
	3.// 定义数据指针
		reg[5:0]txd_p;  //发送数据指针
	4.// 循环
		if(txd_p==19)begin
        txdata <= store[txd_p];